import React from 'react';
 
import './App.css';
 
function App() {
  return (
    <div className="App">
      saugu
       <BarJ/>
    </div>
  );
}

export default App;
